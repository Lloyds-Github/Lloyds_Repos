---
title: functionName
tags: utility,intermediate
---

Explain briefly what the snippet does.

Explain briefly how the snippet works.

```js
const functionName = arguments =>
  {functionBody}
```

```js
functionName('sampleInput'); // 'sampleOutput'
```
