const {UUIDGeneratorBrowser} = require('./_30s.js');

test('UUIDGeneratorBrowser is a Function', () => {
  expect(UUIDGeneratorBrowser).toBeInstanceOf(Function);
});
