const {arrayToHtmlList} = require('./_30s.js');

test('arrayToHtmlList is a Function', () => {
  expect(arrayToHtmlList).toBeInstanceOf(Function);
});
